<?php

require_once 'Curl.php';


/**
 * Class Billing
 */
class Billing {

    private $protocol;
    private $host;
    private $apikey;


    /**
     * Billing constructor.
     * @param string $protocol
     * @param string $host
     * @param string $apikey
     */
    public function __construct($protocol, $host, $apikey) {
        $this->protocol = $protocol;
        $this->host     = $host;
        $this->apikey   = $apikey;
    }


    /**
     * @param string $system_name
     * @param array  $additional_params
     * @return string
     */
    public function successOperation($system_name, $additional_params = array()) {

        $headers = array(
            'Core2-apikey: ' . $this->apikey
        );

        $params = $additional_params;
        $params['system_name'] = $system_name;

        return Curl::post($this->protocol . '://' . $this->host . '/api/billing/success', $params, $headers);
    }


    /**
     * @param string $system_name
     * @param array  $additional_params
     * @return string
     */
    public function cancelOperation($system_name, $additional_params = array()) {

        $headers = array(
            'Core2-apikey: ' . $this->apikey
        );

        $params = $additional_params;
        $params['system_name'] = $system_name;

        return Curl::post($this->protocol . '://' . $this->host . '/api/billing/cancel', $params, $headers);
    }
}