<?php

require_once __DIR__ . '/../classes/Billing.php';

header("Core-Billing-Actions: " . md5_file(__FILE__));

$action       = ! empty($_GET['action'])   ? $_GET['action']   : '';
$service_name = ! empty($_GET['service'])  ? $_GET['service']  : '';
$protocol     = ! empty($_GET['protocol']) ? $_GET['protocol'] : '';
$host         = ! empty($_GET['host'])     ? $_GET['host']     : '';
$apikey       = ! empty($_GET['apikey'])   ? $_GET['apikey']   : '';


if ( ! in_array($protocol, array('http', 'https'))) {
    $protocol = 'http';
}



switch ($service_name) {
    case 'webpay':
        if (isset($_SERVER['HTTP_REFERER']) && substr($_SERVER['HTTP_REFERER'], -11, 10) == '.webpay.by') {
            switch ($action) {
                case 'success':
                    $additional_payment = array(
                        'operation_num'  => ! empty($_GET['wsb_order_num']) ? $_GET['wsb_order_num'] : '',
                        'transaction_id' => ! empty($_GET['wsb_tid'])       ? $_GET['wsb_tid']       : '',
                    );

                    $billing    = new Billing($protocol, $host, $apikey);
                    $result_raw = $billing->successOperation($service_name, $additional_payment);

                    $result = json_decode($result_raw, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        if (isset($result['status']) && $result['status'] == 'success') {
                            $content = "<script>window.location.href = '{$protocol}://{$host}/index.php#module=billing';</script>";
                        } else {
                            $content = isset($result['error_code'])
                                ? 'Ошибка. ' . $result['message']
                                : 'Ошибка, проверьте правильность указанного адреса.';
                        }
                    } else {
                        $content = 'Сервис временно недоступен, попробуйте пожалуйста позже.' . $result_raw;
                    }

                    $tpl = file_get_contents(__DIR__ . '/../index.html');
                    $tpl = str_replace('[CONTENT]',     $content,                $tpl);
                    $tpl = str_replace('[SYSTEM_NAME]', $_SERVER['SERVER_NAME'], $tpl);
                    echo $tpl;
                    break;

                case 'cancel':
                    $additional_payment = array(
                        'operation_num' => ! empty($_GET['wsb_order_num']) ? $_GET['wsb_order_num']  : ''
                    );

                    $billing    = new Billing($protocol, $host, $apikey);
                    $result_raw = $billing->cancelOperation($service_name, $additional_payment);


                    $result = json_decode($result_raw, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        if (isset($result['status']) && $result['status'] == 'success') {
                            $content = "<script>window.location.href = '{$protocol}://{$host}/index.php#module=billing';</script>";
                        } else {
                            $content = isset($result['error_code'])
                                ? 'Ошибка. ' . $result['message']
                                : 'Ошибка, проверьте правильность указанного адреса.';
                        }
                    } else {
                        $content = 'Сервис временно недоступен, попробуйте пожалуйста позже.';
                    }



                    $tpl = file_get_contents(__DIR__ . '/../index.html');
                    $tpl = str_replace('[CONTENT]',     $content,                $tpl);
                    $tpl = str_replace('[SYSTEM_NAME]', $_SERVER['SERVER_NAME'], $tpl);
                    break;

                case 'notify':
                    $additional_payment = array(
                        'operation_num'  => ! empty($_GET['wsb_order_num']) ? $_GET['wsb_order_num']  : '',
                        'transaction_id' => ! empty($_GET['wsb_tid'])       ? $_GET['wsb_tid']        : '',
                    );

                    $billing    = new Billing($protocol, $host, $apikey);
                    $result_raw = $billing->successOperation($service_name, $additional_payment);

                    $result = json_decode($result_raw, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        if (isset($result['status']) && $result['status'] == 'success') {
                            header("HTTP/1.1 200 OK");
                        } else {
                            header("HTTP/1.1 400 Bad Request");
                        }
                        echo  json_encode($result);

                    } else {
                        header("HTTP/1.1 500 Internal Server Error");
                        echo $result_raw;
                    }
                    break;
            }
        }
        break;
}
