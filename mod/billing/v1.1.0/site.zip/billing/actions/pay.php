<?php


header("Core-Billing-Pay: " . md5_file(__FILE__));


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (!empty($_POST['billing_vars']) && !empty($_POST['billing_vars']['action'])) {
            $action = $_POST['billing_vars']['action'];
        } else {
            throw new Exception("<h3>Ошибка платежа!</h3> Не указан адрес патежной системы");
        }


        $form = "<form id=\"billing-form\" action=\"{$action}\" method=\"post\">";
        foreach ($_POST as $k => $value) {
            if ($k != 'billing_vars') {
                if (is_array($value)) {
                    foreach ($value as $k2 => $value2) {
                        if (is_array($value2)) {
                            foreach ($value2 as $k3 => $value3) {
                                if ( ! is_array($value3)) {
                                    $form .= "<input type=\"hidden\" name=\"{$k}[{$k2}][{$k3}]\" value=\"{$value3}\">";
                                }
                            }
                        } else {
                            $form .= "<input type=\"hidden\" name=\"{$k}[{$k2}]\" value=\"{$value2}\">";
                        }
                    }

                } else {
                    $form .= "<input type=\"hidden\" name=\"{$k}\" value=\"{$value}\">";
                }
            }
        }
        $form .= '</form>';
        $scripts = "<script>document.getElementById('billing-form').submit();</script>";
        $content = $form . $scripts;

    } catch(Exception $e) {
        $content = $e->getMessage();
    }


    $tpl = file_get_contents(__DIR__ . '/../index.html');
    $tpl = str_replace('[CONTENT]',     $content,                $tpl);
    $tpl = str_replace('[SYSTEM_NAME]', $_SERVER['SERVER_NAME'], $tpl);
    echo $tpl;
}
